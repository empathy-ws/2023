# LaTeX user template and guide

To compile user guide:

1. `pdflatex sample-1col`
2. `bibtex sample-1col`
3. `pdflatex sample-1col`
4. `pdflatex sample-1col`

and

1. `pdflatex sample-2col`
2. `bibtex sample-2col`
3. `pdflatex sample-2col`
4. `pdflatex sample-2col`

or

use the makefile:

`make`



--- 
Word / LibreOffice templates

The Latex styles sample*.tex are approximated by DOCX (MS Word) and 
ODT (LibreOffice) templates. 
If you experiencing problems with opening the DOCX file in your
version of WOrd, then try the ODT with either MS Word or LibreOffice.

